"""Verified tracking enable through the shared INDI OnStep device."""

from __future__ import annotations

from dataclasses import dataclass
import time
from typing import Callable

from .indi_meridian import IndiMeridianState
from .indi_status import IndiMountSnapshot
from .indi_transport import IndiTransport


@dataclass(frozen=True)
class IndiTrackingResult:
    command_accepted: bool
    tracking_confirmed: bool
    consecutive_tracking_polls: int
    final_raw_status: str | None
    meridian_phase: str
    error: str | None = None
    warnings: tuple[str, ...] = ()
    authority_policy: str = "strict"


def enable_tracking_via_indi(
    transport: IndiTransport,
    device: str,
    *,
    observe: Callable[[], IndiMountSnapshot],
    meridian_status: Callable[[], IndiMeridianState],
    emergency_stop: Callable[[], object],
    timeout: float = 8.0,
    authority_policy: str = "strict",
) -> IndiTrackingResult:
    """Enable tracking under strict or explicit controller-managed authority."""
    if authority_policy not in {"strict", "controller_managed"}:
        raise ValueError("Unknown tracking authority policy")
    before = observe()
    meridian = meridian_status()
    hard_blockers = {
        "indi_device_disconnected", "onstep_status_not_fresh",
        "onstep_status_alert",
        "onstep_status_unavailable", "onstep_limit_or_park_fault",
        "onstep_reported_error",
    }.intersection(before.blockers)
    authority_blockers = {
        "coordinates_not_fresh", "pier_side_conflict", "pier_side_unknown",
        "coordinates_invalid", "time_site_authority_unestablished",
        "hour_angle_unavailable", "home_authority_unestablished",
        "mechanical_terminal_state",
    }.intersection(before.blockers)
    warnings = tuple(sorted(authority_blockers))
    allowed_phases = {
        "pre_meridian_allowed", "post_meridian_allowed", "post_flip",
    }
    strict_refusal = authority_policy == "strict" and (
        authority_blockers or not before.coordinates_live or
        not before.time_site_authority or not before.home_authority or
        before.at_home or meridian.phase not in allowed_phases
    )
    if (
        hard_blockers or not before.status_live or before.parked or
        before.slewing or before.at_limit or strict_refusal or
        meridian.tracking_stop_required
    ):
        reason = (
            f"tracking preflight refused: blockers={sorted(hard_blockers | authority_blockers)} "
            f"phase={meridian.phase}"
        )
        return IndiTrackingResult(
            False, False, 0, before.raw_status, meridian.phase, reason,
            warnings, authority_policy,
        )
    if before.tracking:
        return IndiTrackingResult(
            False, True, 2, before.raw_status, meridian.phase, None,
            warnings, authority_policy,
        )

    accepted = False
    try:
        transport.issue_switch(device, "TELESCOPE_TRACK_STATE", "TRACK_ON")
        accepted = True
        deadline = time.monotonic() + timeout
        stable = 0
        last_revision = before.status_revision
        last_raw = before.raw_status
        while stable < 2:
            if time.monotonic() >= deadline:
                raise TimeoutError("Tracking ON was not confirmed by fresh OnStep status")
            time.sleep(0.15)
            current = observe()
            if current.status_revision <= last_revision:
                continue
            last_revision = current.status_revision
            last_raw = current.raw_status
            if current.at_limit or current.parked or (
                authority_policy == "strict" and current.at_home
            ):
                raise RuntimeError("Unsafe state appeared while enabling tracking")
            current_meridian = meridian_status()
            if authority_policy == "strict" and (
                current_meridian.phase not in allowed_phases or
                current_meridian.tracking_stop_required
            ):
                raise RuntimeError(
                    f"Meridian state became unsafe: {current_meridian.phase}"
                )
            stable = stable + 1 if current.tracking and not current.slewing else 0
        return IndiTrackingResult(
            True, True, stable, last_raw, meridian.phase, None,
            warnings, authority_policy,
        )
    except (ConnectionError, RuntimeError, TimeoutError, ValueError) as exc:
        if accepted:
            emergency_stop()
        return IndiTrackingResult(
            accepted, False, 0, before.raw_status, meridian.phase, str(exc),
            warnings, authority_policy,
        )
