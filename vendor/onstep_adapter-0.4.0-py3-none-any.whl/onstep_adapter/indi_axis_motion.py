"""Finite, feedback-checked INDI axis-angle test moves."""

from __future__ import annotations

from dataclasses import dataclass
import math
import threading
import time
from typing import Callable, Literal

from .indi_status import IndiMountSnapshot
from .indi_transport import IndiTransport

Axis = Literal["ra", "dec"]


@dataclass(frozen=True)
class IndiAxisMoveResult:
    axis: Axis
    requested_deg: float
    requested_arcsec: float
    measured_deg: float
    initial_ra_hours: float
    final_ra_hours: float
    initial_dec_deg: float
    final_dec_deg: float
    pier_side: str
    stop_confirmed: bool
    samples: int
    verification_required: bool = True


class IndiAxisMover:
    """Use a finite target, never an indefinite manual-motion switch.

    Positive RA-axis angle increases HA (westward); positive DEC is northward.
    Logical coordinates are not independent mechanical encoders.
    """

    def __init__(
        self, transport: IndiTransport, device: str, observer_lat_deg: float,
        observer_lon_deg: float, observe: Callable[[], IndiMountSnapshot],
        emergency_stop: Callable[[], object],
    ) -> None:
        self.transport = transport
        self.device = device
        self.observer_lat_deg = observer_lat_deg
        self.observer_lon_deg = observer_lon_deg
        self.observe = observe
        self.emergency_stop = emergency_stop
        self._lock = threading.Lock()

    @staticmethod
    def _check(snapshot: IndiMountSnapshot, *, moving: bool = False) -> None:
        forbidden = {
            "indi_device_disconnected", "onstep_status_not_fresh",
            "coordinates_not_fresh", "onstep_status_alert",
            "onstep_status_unavailable", "onstep_limit_or_park_fault",
            "onstep_reported_error", "pier_side_conflict", "pier_side_unknown",
            "coordinates_invalid",
        }
        blockers = forbidden.intersection(snapshot.blockers)
        if blockers or not snapshot.status_live or not snapshot.coordinates_live:
            raise RuntimeError(f"Axis motion safety inputs unavailable: {sorted(blockers)}")
        if (
            snapshot.at_limit or snapshot.parked or
            (snapshot.tracking and not moving) or
            (snapshot.slewing and not moving) or
            snapshot.pier_side not in {"east", "west"} or
            snapshot.ra_hours is None or snapshot.dec_deg is None
        ):
            raise RuntimeError(
                "Local axis motion requires fresh unparked, stationary, "
                "non-tracking and fault-free state"
            )

    @staticmethod
    def _ra_axis_delta(initial_ra: float, current_ra: float) -> float:
        # Increasing HA is the opposite of increasing RA.
        return -((current_ra - initial_ra + 12.0) % 24.0 - 12.0) * 15.0

    def move(
        self, axis: Axis, offset_deg: float, *, timeout_s: float = 30.0,
        poll_s: float = 0.1,
    ) -> IndiAxisMoveResult:
        if axis not in {"ra", "dec"}:
            raise ValueError("axis must be ra or dec")
        if not math.isfinite(offset_deg) or not 0.2 <= abs(offset_deg) <= 10.0:
            raise ValueError("Axis move must be between 0.2 and 10 degrees")
        if not math.isfinite(timeout_s) or not 1 <= timeout_s <= 60:
            raise ValueError("Axis move timeout must be between 1 and 60 seconds")
        if not math.isfinite(poll_s) or not 0.05 <= poll_s <= 0.25:
            raise ValueError("Axis move poll interval must be 0.05..0.25 seconds")
        if not self._lock.acquire(blocking=False):
            raise RuntimeError("Another axis motion is active")
        issued = False
        try:
            before = self.observe()
            self._check(before)
            assert before.ra_hours is not None and before.dec_deg is not None
            target_dec = before.dec_deg + (offset_deg if axis == "dec" else 0.0)
            target_ra = (
                before.ra_hours - offset_deg / 15.0
                if axis == "ra" else before.ra_hours
            ) % 24.0
            if not -80.0 <= target_dec <= 80.0:
                raise RuntimeError("Projected DEC leaves the local movement bound")
            self.transport.set_switch(self.device, "ON_COORD_SET", "SLEW")
            issued = True
            self.transport.issue_numbers(
                self.device, "EQUATORIAL_EOD_COORD",
                {"RA": target_ra, "DEC": target_dec},
            )
            deadline = time.monotonic() + timeout_s
            count = 0
            latest = before
            last_coord_revision = before.coordinates_revision
            stable = 0
            while stable < 2:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Axis move did not reach its finite target")
                time.sleep(poll_s)
                latest = self.observe()
                self._check(latest, moving=True)
                if latest.pier_side != before.pier_side:
                    raise RuntimeError("Pier side changed during axis move")
                if latest.coordinates_revision <= last_coord_revision:
                    continue
                last_coord_revision = latest.coordinates_revision
                count += 1
                assert latest.ra_hours is not None and latest.dec_deg is not None
                delta = (
                    self._ra_axis_delta(before.ra_hours, latest.ra_hours) if axis == "ra"
                    else latest.dec_deg - before.dec_deg
                )
                signed = delta * (1 if offset_deg > 0 else -1)
                if signed < -0.35 or signed > abs(offset_deg) + 0.35:
                    raise RuntimeError("Axis move reversed or overran its finite target")
                reached = abs(delta - offset_deg) <= 0.35
                other_axis_ok = (
                    abs(latest.dec_deg - before.dec_deg) <= 0.25 if axis == "ra"
                    else abs(self._ra_axis_delta(before.ra_hours, latest.ra_hours)) <= 0.35
                )
                stable = stable + 1 if reached and other_axis_ok and not latest.slewing else 0
            self.transport.set_switch(self.device, "TELESCOPE_TRACK_STATE", "TRACK_OFF")
            stopped_polls = 0
            last_revision = latest.status_revision
            stop_deadline = time.monotonic() + 5.0
            while stopped_polls < 2:
                if time.monotonic() >= stop_deadline:
                    raise TimeoutError("Axis move tracking-off was not confirmed")
                time.sleep(max(poll_s, 0.15))
                sample = self.observe()
                self._check(sample, moving=True)
                if sample.pier_side != before.pier_side:
                    raise RuntimeError("Pier side changed after axis move")
                if sample.status_revision <= last_revision:
                    continue
                last_revision = sample.status_revision
                stopped_polls = stopped_polls + 1 if not sample.tracking and not sample.slewing else 0
                latest = sample
            assert latest.ra_hours is not None and latest.dec_deg is not None
            measured = (
                self._ra_axis_delta(before.ra_hours, latest.ra_hours) if axis == "ra"
                else latest.dec_deg - before.dec_deg
            )
            if abs(measured - offset_deg) > 0.35:
                raise RuntimeError("Axis move ended outside the 0.35-degree test tolerance")
            return IndiAxisMoveResult(
                axis, offset_deg, offset_deg * 3600.0, measured,
                before.ra_hours, latest.ra_hours,
                before.dec_deg, latest.dec_deg, before.pier_side, True, count,
            )
        except BaseException:
            if issued:
                self.emergency_stop()
            raise
        finally:
            self._lock.release()
